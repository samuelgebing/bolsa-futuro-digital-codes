/* exe5.js
Nesse exercício o aluno precisa:
 - percorrer os números menores que num;
 - verificar divisibilidade com %;
 - somar os divisores;
 - comparar a soma com o valor original.
*/

function numeroPerfeito(num) {
  let soma = 0;

  // Procura os divisores próprios de num
  for (let i = 1; i < num; i++) {
    if (num % i === 0) {
      soma += i;
    }
  }

  // Retorna true se a soma dos divisores for igual ao número
  return soma === num;
}

// Chamada da função
let valor = 6;

if (numeroPerfeito(valor)) {
  console.log("Número perfeito");
} else {
  console.log("Número não perfeito");
}