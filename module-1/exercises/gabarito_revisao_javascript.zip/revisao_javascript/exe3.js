/* exe3.js
Esse é o exercício mais interessante para avaliar lógica condicional. O aluno precisa:
 - identificar corretamente a faixa salarial;
 - aplicar alíquota e dedução;
 - depois aplicar a redução extra descrita na atividade.
*/
// exe3.js

function calcularIRPF(baseCalculo) {
  let imposto = 0;
  let reducao = 0;

  // 1. Calcula o imposto conforme a faixa salarial
  if (baseCalculo <= 2428.80) {
    imposto = 0;
  } else if (baseCalculo <= 2826.65) {
    imposto = (baseCalculo * 0.075) - 182.16;
  } else if (baseCalculo <= 3751.05) {
    imposto = (baseCalculo * 0.15) - 394.16;
  } else if (baseCalculo <= 4664.68) {
    imposto = (baseCalculo * 0.225) - 675.49;
  } else {
    imposto = (baseCalculo * 0.275) - 908.73;
  }

  // 2. Calcula a redução do imposto
  if (baseCalculo <= 5000) {
    reducao = 312.89;
  } else if (baseCalculo <= 7350) {
    reducao = 978.62 - (0.133145 * baseCalculo);
  } else {
    reducao = 0;
  }

  // 3. Aplica a redução
  imposto = imposto - reducao;

  // 4. Se o imposto ficar negativo, o valor final deve ser zero
  if (imposto < 0) {
    imposto = 0;
  }

  return imposto.toFixed(2);
}

// Exemplo de uso
console.log("IRPF: R$", calcularIRPF(3000));
console.log("IRPF: R$", calcularIRPF(5500));
console.log("IRPF: R$", calcularIRPF(8000));