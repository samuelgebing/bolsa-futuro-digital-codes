/* exe1.js
Aqui o estudante pratica:
 - criação de função com parâmetros;
 - uso de Math.sqrt();
 - uso de potência com **;
 - formatação com toFixed(4).
*/

// Função que calcula a distância entre dois pontos no plano
function calcularDistancia(x1, y1, x2, y2) {
  // Fórmula da distância:
  // d = √((x2 - x1)² + (y2 - y1)²)
  let distancia = Math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2);

  // toFixed(4) retorna uma string com 4 casas decimais
  return distancia.toFixed(4);
}

// Chamada da função
let resultado = calcularDistancia(1, 2, 4, 6);

// Exibição do resultado
console.log("Distância:", resultado);

