/* exe2.js

Esse exercício trabalha:
 - extração de partes da string com substring(), como pede o enunciado;
 - uso de if para validar se a pessoa já fez aniversário no ano atual;
 - manipulação básica de datas com Date.
*/

function calcularIdade(dataNascimento) {
  // Espera-se uma data no formato dd/mm/aaaa
  let dia = parseInt(dataNascimento.substring(0, 2));
  let mes = parseInt(dataNascimento.substring(3, 5));
  let ano = parseInt(dataNascimento.substring(6, 10));

  let hoje = new Date();
  let diaAtual = hoje.getDate();
  let mesAtual = hoje.getMonth() + 1; // Janeiro = 0
  let anoAtual = hoje.getFullYear();

  let idade = anoAtual - ano;

  // Se ainda não fez aniversário neste ano, diminui 1
  if (mesAtual < mes) {
    idade--;
  } else if (mesAtual === mes && diaAtual < dia) {
    idade--;
  }

  return idade;
}

// Chamada da função
let idadePessoa = calcularIdade("15/08/2000");

// Exibição do resultado
console.log("Idade:", idadePessoa, "anos");