/* exe4.js
Aqui o aluno pratica:
 - laço de repetição;
 - variável acumuladora;
 - retorno da função.
*/

function fatorial(numero) {
  let resultado = 1;

  // Se o número for 0, o fatorial é 1
  for (let i = numero; i >= 1; i--) {
    resultado *= i;
  }

  return resultado;
}

// Chamada da função
let valorFatorial = fatorial(5);

// Exibição do resultado
console.log("Fatorial:", valorFatorial);