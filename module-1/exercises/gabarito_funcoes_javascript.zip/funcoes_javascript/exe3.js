function soma(a, b) {
    console.log(a + b);
}

soma(3, 7);
