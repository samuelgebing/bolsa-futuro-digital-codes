function dobro(numero) {
    return numero * 2;
}

let resultado = dobro(5);
console.log(resultado);
