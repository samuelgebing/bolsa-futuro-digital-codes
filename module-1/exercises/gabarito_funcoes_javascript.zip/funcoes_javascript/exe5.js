function cumprimento(nome = "Visitante") {
    console.log("Bem-vindo, " + nome + "!");
}

cumprimento("Ana");
cumprimento();
