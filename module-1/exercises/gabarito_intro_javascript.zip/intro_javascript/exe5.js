let texto = "42";

// Converte a string para número e soma com 8
let resultado = Number(texto) + 8;

console.log("Resultado da soma:", resultado);
