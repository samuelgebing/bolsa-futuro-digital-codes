// Exibe uma mensagem simples no console
console.log("Olá, estou aprendendo JavaScript!");