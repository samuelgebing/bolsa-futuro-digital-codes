// Criação de variáveis
let nome = "Ana";
const idade = 20;

// Exibe uma mensagem formatada com template string
console.log(`Meu nome é ${nome} e tenho ${idade} anos.`);
